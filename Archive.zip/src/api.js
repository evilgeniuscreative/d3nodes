// src/api.js

export async function searchUsers(query) {
  const searchQuery = `
    query($query: String!) {
      search(query: $query, type: USER, first: 10) {
        nodes {
          ... on User {
            login
            name
            avatarUrl
          }
        }
      }
    }
  `;

  const res = await fetch("/api/github/graphql", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query: searchQuery, variables: { query } }),
  });

  const { data, errors } = await res.json();
  if (errors) throw new Error(errors.map(e => e.message).join("; "));

  return data.search.nodes;
}


export async function fetchUserAndConnections(login) {
  const query = `
    query($login: String!) {
      user(login: $login) {
        login
        name
        avatarUrl
        email
        company
        bio
        twitterUsername
        url
        websiteUrl
        createdAt
        updatedAt
        followers(first: 100) {
          nodes {
            login
            avatarUrl
            name
          }
        }
        following(first: 100) {
          nodes {
            login
            avatarUrl
            name
          }
        }
        publicRepos: repositories(privacy: PUBLIC) {
          totalCount
        }
        privateRepos: repositories(privacy: PRIVATE) {
          totalCount
        }
        publicGists: gists(privacy: PUBLIC) {
          totalCount
        }
        totalPrivateRepos: repositories(privacy: PRIVATE, ownerAffiliations: [OWNER]) {
          totalCount
        }
      }
      rateLimit {
        limit
        remaining
        resetAt
      }
    }
  `;

  const res = await fetch("/api/github/graphql", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, variables: { login } }),
  });

  const { data, errors } = await res.json();
  if (errors) throw new Error(errors.map(e => e.message).join("; "));

  const user = data.user;
  const followers = user.followers.nodes;
  const following = user.following.nodes;

  const dedupeNodes = (users) => {
    const seen = new Set();
    return users.filter(user => {
      if (seen.has(user.login)) return false;
      seen.add(user.login);
      return true;
    });
  };
  
  const nodes = dedupeNodes([user, ...followers, ...following]);
  
  const links = [
    ...followers.map(f => ({ source: f.login, target: user.login })),
    ...following.map(f => ({ source: user.login, target: f.login }))
  ];

  return {
    nodes,
    links,
    rateLimit: data.rateLimit
  };
}